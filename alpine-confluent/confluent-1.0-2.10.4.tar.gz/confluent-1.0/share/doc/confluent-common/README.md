Confluent Commons
=================

Contains 3 libraries

1. Metrics
To build the metrics sub project independently, run this from the parent directory
mvn -pl :common-metrics package 
2. Config
To build the config sub project independently, run this from the parent directory
mvn -pl :common-config package
3. Utils
To build the utils sub project independently, run this from the parent directory
mvn -pl :common-utils package
